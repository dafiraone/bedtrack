// src/lib/server/auth.ts
export interface UserSession {
  id: number;
  username: string;
  role: string;
}

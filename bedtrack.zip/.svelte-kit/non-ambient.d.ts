
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/admin" | "/admin/admissions" | "/admin/admissions/[id]" | "/admin/reports" | "/admin/rooms" | "/admin/staff" | "/api" | "/api/discharge" | "/logout" | "/patient" | "/patient/[id]" | "/rooms";
		RouteParams(): {
			"/admin/admissions/[id]": { id: string };
			"/patient/[id]": { id: string }
		};
		LayoutParams(): {
			"/": { id?: string };
			"/admin": { id?: string };
			"/admin/admissions": { id?: string };
			"/admin/admissions/[id]": { id: string };
			"/admin/reports": Record<string, never>;
			"/admin/rooms": Record<string, never>;
			"/admin/staff": Record<string, never>;
			"/api": Record<string, never>;
			"/api/discharge": Record<string, never>;
			"/logout": Record<string, never>;
			"/patient": { id?: string };
			"/patient/[id]": { id: string };
			"/rooms": Record<string, never>
		};
		Pathname(): "/" | "/admin" | "/admin/" | "/admin/admissions" | "/admin/admissions/" | `/admin/admissions/${string}` & {} | `/admin/admissions/${string}/` & {} | "/admin/reports" | "/admin/reports/" | "/admin/rooms" | "/admin/rooms/" | "/admin/staff" | "/admin/staff/" | "/api" | "/api/" | "/api/discharge" | "/api/discharge/" | "/logout" | "/logout/" | "/patient" | "/patient/" | `/patient/${string}` & {} | `/patient/${string}/` & {} | "/rooms" | "/rooms/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}